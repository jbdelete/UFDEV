function F = FigureStruct()

    F = struct();
    F.Caption = "";
    F.FigData = {};
    F.ImagesNames = {};
    F.ImageHandles = [];

end