function PlotTitle(Title)
	title(Title)
end
