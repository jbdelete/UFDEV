

function r = PlotAxisDimensions(LowestX, UpperX, LowerY, UpperY)
	printf('This is PlotAxisDimensions\r\n');
axis([LowestX, UpperX, LowerY, UpperY])	;
end