function ret = PlotEnd(h)
close(h);
ret = 0;
end