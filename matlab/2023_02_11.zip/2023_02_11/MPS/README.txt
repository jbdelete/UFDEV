%********************************************************************
%***                     SVN CHANGE RECORD                       ***
%*******************************************************************
%*$Revision:  $
%* README
%*
%******************************************************************/

This software is a serial protype of the chromatic sub-division method.

The main.m file is the master file. 
It runs a configuration file specied in  mp.SetTestFile('mtestXXX').

mtest001.m -> Test different collisions between spheres.
mtest002.m -> Test different collisions between spheres and walls.
mtest003.m -> Test multiple particles contained in multiple voxels.

