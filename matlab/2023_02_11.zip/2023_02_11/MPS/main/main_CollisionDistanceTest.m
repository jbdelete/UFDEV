addPathCD('matlab/MPS/main')

clc
clear all;
close all;
fclose all;


xt = 0.75;
yt = 0.75;
zt = 0.75;

xp = 1.2500;
yp = 0.75;
zp = 0.75;

dsq = (xt-xp)^2+(yt-yp)^2+(zt-zp)^2
rsq = (0.20+0.20)^2
