function totpart = CalcCellOccupancy(R)

    Len = R+R/4;
    sidenum = 1.0/Len;
    totpart = sidenum^3;




end