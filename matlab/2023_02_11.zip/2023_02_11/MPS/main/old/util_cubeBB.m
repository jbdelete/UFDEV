clc
clear all
close all

x = 10;
y = 10;
R = 6;
nw = [x-R/2,y+R/2]
sw = [x-R/2,y-R/2]
ne = [x+R/2,y+R/2]
se = [x+R/2,y-R/2]

