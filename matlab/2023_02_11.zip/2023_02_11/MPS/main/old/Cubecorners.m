clc
clear all
close all


R = 2
cx = 0
cy = 0
cz = 0
loc(1,:) = [cx+R/2,cy+R/2,cz+R/2]
loc(2,:) = [cx-R/2,cy+R/2,cz+R/2]
loc(3,:) = [cx+R/2,cy-R/2,cz+R/2]
loc(4,:) = [cx-R/2,cy-R/2,cz-R/2]
loc(5,:) = [cx+R/2,cy+R/2,cz-R/2]
loc(6,:) = [cx-R/2,cy-R/2,cz+R/2]
loc(7,:) = [cx-R/2,cy+R/2,cz-R/2]
loc(8,:) = [cx+R/2,cy-R/2,cz-R/2]

