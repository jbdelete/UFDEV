    squr = 2.0;
    %squr = 5.0;  %Collisons:284 Of :343 Particles, Colocated:0 SideLen:4 Radius:0.15 Duration:0.0061412 s
    %squr = 10.0; %Collisons:3014 Of :4096 Particles, Colocated:0 SideLen:9 Radius:0.15 Duration:0.95468 s
    %squr = 20.0; %Collisons:18848 Of :32768 Particles, Colocated:6 SideLen:19 Radius:0.15 Duration:55.8496 s
    %squr = 30.0;  %Collisons:66276 Of :117649 Particles, Colocated:26 SideLen:29 Radius:0.15 Duration:729.964 s
    %squr = 40.0;  %Collisons:161978 Of :287496 Particles, Colocated:46 SideLen:39 Radius:0.15 Duration:(73min)4420.54 s
    %squr = 50.0;  %Collisons:298938 Of :551368 Particles, Colocated:98 SideLen:49 Radius:0.15 Duration:16188.2 s
    %squr = 60.0;  %
    
    %squr = 70.0;
    %squr = 80.0;
    %squr = 90.0;
    %squr = 100.0;
    %squr = 130.0;

    % For perfdata
    %aa = 1.50; 
    %bb = squr;
    %margin = 0.60;
 %   RR = 0.15;

    %For testing collsions
    aa = 1.1; 
    bb = squr;
    margin = 0.52;
    RR = 0.10;
    
    xstart = 0.9;
    xend = squr;
    ystart = 0.9;
    yend = squr;
    zstart = 0.9;
    zend = squr;
    sideleng = 0;
    
    count = 0;
  