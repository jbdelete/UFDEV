addpath('J:/sandboxR7/svnmatlab/mps')
addpath('J:/sandboxR7/svnmatlab/mps/common')
addpath('J:/sandboxR7/svnmatlab/mps/main')

clc
clear all
close all

