function index = Loc2index(X,Y,Z,L)


%index = X+Y*L+Z*L^2;

index = X*L^2+Y*L+Z;




end
