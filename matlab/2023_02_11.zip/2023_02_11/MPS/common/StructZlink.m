function outstruct = StructZlink()



 pstruct           = struct(...  		
			    'zlink',			    zeros(6,4),...   % Particle number.
                'end',		        0); 
outstruct = pstruct;

end