%addpath('J:/sandboxR7/svnmatlab/Latex')
addpath('../../mps')
addpath('../common')
%addpath('../latex/export_fig')
